#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

int elMasProbable (int iArr[])
{
    int iNum;
    int iMax = INT_MIN;
    for(int i = 2; i < 13; i++)
    {
        if(iArr[i] > iMax)
            iMax = iArr[i];
    }
    for(int i = 2; i < 13; i++)
    {
        if(iArr[i] == iMax)
        {
            iNum = i;
            return iNum;
        }
    }
}

int elMenosProbable (int iArr[])
{
    int iNum;
    int iMin = INT_MAX;
    for(int i = 2; i < 13; i++)
    {
        if(iArr[i] < iMin)
            iMin = iArr[i];
    }
    for(int i = 2; i < 13; i++)
    {
        if(iArr[i] == iMin)
        {
            iNum = i;
            return iNum;
        }
    }
}


int main()
{
    int iDado1, iDado2, iSuma, iArr[] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
    ofstream ofArchivoTexto;
    ofArchivoTexto.open("Histograma.txt");

    srand(time(0));
    for(int i = 0; i < 200; i++)
    {
        iDado1 = 1 + rand()%6;
        iDado2 = 1 + rand()%6;

        iSuma = iDado1 + iDado2;
        iArr[iSuma]++;
    }
    for (int j = 2; j < 13; j++)
    {
        ofArchivoTexto << j << "|";
        for (int k = 0; k < iArr[j]; k++)
            ofArchivoTexto << "*";
        ofArchivoTexto << "\n";
    }

    ofArchivoTexto << "El valor que tiene m�s probabilidad de salir es: " << elMasProbable(iArr) << endl;
    ofArchivoTexto << "El valor que tiene menos probabilidad de salir es: " << elMenosProbable(iArr) << endl;

    return 0;
}
