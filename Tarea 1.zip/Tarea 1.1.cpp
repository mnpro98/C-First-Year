#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    string sNum;
    int iNum;
    int iSizeOfString = 3;
    ifstream ifArchivoEntrada;
    ifArchivoEntrada.open("NumerosConComas.txt");
    while(getline(ifArchivoEntrada,sNum))
    {
        while(sNum.size()>iSizeOfString){
            sNum.insert((sNum.size()-iSizeOfString),",");
            iSizeOfString += 4;
        }
        cout << sNum << endl;
        iSizeOfString = 3;
    }
    ifArchivoEntrada.close();
    return 0;
}
