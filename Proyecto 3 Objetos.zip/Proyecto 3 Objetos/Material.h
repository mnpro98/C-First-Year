#ifndef Materia1_h_included
#define Materia1_h_included
#include <iostream>

using namespace std;

class Material
{
protected:
    int idMaterial;
    string titulo;
public:
    Material()
    {
        idMaterial = 0;
        titulo = "N/A";
    }
    Material(int mat, string t)
    {
        idMaterial = mat;
        titulo = t;
    }

    int getMat()
    {
        return idMaterial;
    }
    string getTitulo()
    {
        return titulo;
    }

    void setMat(int mat)
    {
        idMaterial = mat;
    }
    void setTitulo(string t)
    {
        titulo = t;
    }

    virtual void muestra() = 0;
    virtual int cantidadDeDiasDePrestamo() = 0;
};
#endif
