#include <iostream>
#include "Material.h"

using namespace std;

class Disco:public Material
{
private:
    int duracion;
public:
    Disco():Material()
    {
        duracion = 0;
    }
    Disco(int mat, string t, int d):Material(mat,t)
    {
        duracion = d;
    }

    int getDuracion()
    {
        return duracion;
    }

    void setDuracion(int d)
    {
        duracion = d;
    }

    virtual void muestra()
    {
        cout << "ID Material:\t" << idMaterial << endl;
        cout << "Titulo:\t" << titulo << endl;
        cout << "Duracion:\t" << duracion << endl;
    }
    virtual int cantidadDeDiasDePrestamo()
    {
        return 3;
    }
};
