#ifndef Fecha_h_included
#define Fecha_h_included
#include <iostream>

using namespace std;

class Fecha
{
private:
    int dd, mm, aa;
    string nombreMes()
    {
        switch (mm)
        {
        case 1:
            return "Ene";
            break;
        case 2:
            return "Feb";
            break;
        case 3:
            return "Mar";
            break;
        case 4:
            return "Abr";
            break;
        case 5:
            return "May";
            break;
        case 6:
            return "Jun";
            break;
        case 7:
            return "Jul";
            break;
        case 8:
            return "Ago";
            break;
        case 9:
            return "Sep";
            break;
        case 10:
            return "Oct";
            break;
        case 11:
            return "Nov";
            break;
        case 12:
            return "Dic";
            break;
        }
    }
    bool esBisiesto()
    {
        if(mm == 2 && dd == 29)
        {
            return true;
        }
        return false;
    }
public:
    Fecha()
    {
        dd = 0;
        mm = 0;
        aa = 0;
    }
    void setFecha(int d, int m, int a)
    {
        dd = d;
        mm = m;
        aa = a;
    }

    int getDd()
    {
        return dd;
    }
    int getMm()
    {
        return mm;
    }
    int getAa()
    {
        return aa;
    }

    void setDd(int d)
    {
        dd = d;
    }
    void setMm(int m)
    {
        mm = m;
    }
    void setAa(int a)
    {
        aa = a;
    }

    friend Fecha operator+(Fecha F1, int d)
    {
        Fecha F2;
        F2.setFecha(F1.getDd(),F1.getMm(),F1.getAa());
        F2.setDd(F2.getDd() + d);
        if((F2.getMm() == 1 || F2.getMm() == 3 || F2.getMm() == 5 || F2.getMm() == 7 || F2.getMm() == 8 || F2.getMm() == 10 || F2.getMm() == 12)&&(F2.getDd() > 31))
        {
            while (F2.getDd() > 31)
            {
                F2.setDd(F2.getDd() - 31);
                F2.setMm(F2.getMm() + 1);
            }
        }
        else if ((F2.getMm() == 4 || F2.getMm() == 6 || F2.getMm() == 9 || F2.getMm() == 11)&&(F2.getDd() > 30))
        {
           while (F2.getDd() > 30)
            {
                F2.setDd(F2.getDd() - 30);
                F2.setMm(F2.getMm() + 1);
            }
        }
        else if ((F2.getMm() == 2)&&(F2.getDd() > 29)&&(F2.esBisiesto() == true))
        {
           while (F2.getDd() > 29)
            {
                F2.setDd(F2.getDd() - 29);
                F2.setMm(F2.getMm() + 1);
            }
        }
        else if ((F2.getMm() == 2)&&(F2.getDd() > 28)&&(F2.esBisiesto() == false))
        {
           while (F2.getDd() > 28)
            {
                F2.setDd(F2.getDd() - 28);
                F2.setMm(F2.getMm() + 1);
            }
        }
        return F2;
    }
    friend bool operator>=(Fecha F1, Fecha F2)
    {
        if(F1.getAa() > F2.getAa())
        {
            return true;
        }
        else if (F1.getAa() == F2.getAa())
        {
            if(F1.getMm() > F2.getMm())
            {
                return true;
            }
            else if (F1.getMm() == F2.getMm())
            {
                if(F1.getDd() > F2.getDd())
                {
                    return true;
                }
                else if (F1.getDd() == F2.getDd())
                {
                    return true;
                }
            }
        }
        return false;
    }
    friend bool operator<=(Fecha F1, Fecha F2)
    {
        if(F2.getAa() > F1.getAa())
        {
            return true;
        }
        else if (F2.getAa() == F1.getAa())
        {
            if(F2.getMm() > F1.getMm())
            {
                return true;
            }
            else if (F2.getMm() == F1.getMm())
            {
                if(F2.getDd() > F1.getDd())
                {
                    return true;
                }
                else if (F2.getDd() == F1.getDd())
                {
                    return true;
                }
            }
        }
        return false;
    }
    friend bool operator>(Fecha F1, Fecha F2)
    {
        if(F1.getAa() > F2.getAa())
        {
            return true;
        }
        else if (F1.getAa() == F2.getAa())
        {
            if(F1.getMm() > F2.getMm())
            {
                return true;
            }
            else if (F1.getMm() == F2.getMm())
            {
                if(F1.getDd() > F2.getDd())
                {
                    return true;
                }
            }
        }
        return false;
    }
    friend bool operator<(Fecha F1, Fecha F2)
    {
        if(F2.getAa() > F1.getAa())
        {
            return true;
        }
        else if (F2.getAa() == F1.getAa())
        {
            if(F2.getMm() > F1.getMm())
            {
                return true;
            }
            else if (F2.getMm() == F1.getMm())
            {
                if(F2.getDd() > F1.getDd())
                {
                    return true;
                }
            }
        }
        return false;
    }
    friend bool operator==(Fecha F1, Fecha F2)
    {
        if(F1.getAa() == F2.getAa() && F1.getMm() == F2.getMm() && F1.getDd() == F2.getDd())
        {
            return true;
        }
        return false;
    }
    friend istream &operator>>(istream &i, Fecha& F1)
    {
        cout << "Introducir dia: ";
        i >> F1.dd;
        cout << "Introducir mes: ";
        i >> F1.mm;
        cout << "Introducir a�o: ";
        i >> F1.aa;
        return i;
    }
    friend ostream &operator<<(ostream &o, Fecha F1)
    {
        cout << F1.getDd() << " " << F1.getMm() << " " << F1.getAa();
        return o;
    }
};
#endif // Fecha_h_included
