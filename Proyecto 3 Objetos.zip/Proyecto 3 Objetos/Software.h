#include <iostream>
#include "Material.h"

using namespace std;

class Software:public Material
{
private:
    string sistemaOper;
public:
    Software():Material()
    {
        sistemaOper = "N/A";
    }
    Software(int mat, string t, string so):Material(mat,t)
    {
        sistemaOper = so;
    }

    string getSisOp()
    {
        return sistemaOper;
    }

    void setSisOp(string so)
    {
        sistemaOper = so;
    }

    virtual void muestra()
    {
        cout << "ID Material:\t" << idMaterial << endl;
        cout << "Titulo:\t" << titulo << endl;
        cout << "Sistema operativo:\t" << sistemaOper << endl;
    }
    virtual int cantidadDeDiasDePrestamo()
    {
        return 1;
    }
};
