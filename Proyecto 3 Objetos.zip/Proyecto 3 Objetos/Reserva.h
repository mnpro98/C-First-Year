#include "Fecha.h"

class Reserva
{
private:
    int idMaterial, idCliente;
    Fecha fechaReservacion;
public:
    Reserva()
    {
        idMaterial = 0;
        idCliente = 0;
    }
    Reserva(int mat, int cliente, Fecha fecha)
    {
        idMaterial = mat;
        idCliente = cliente;
        fechaReservacion = fecha;
    }
    int getMaterial()
    {
        return idMaterial;
    }
    int getCliente()
    {
        return idCliente;
    }
    Fecha getFecha()
    {
        return fechaReservacion;
    }
    void setMaterial(int mat)
    {
        idMaterial = mat;
    }
    void setCliente(int cliente)
    {
        idCliente = cliente;
    }
    void setFecha(Fecha fecha)
    {
        fechaReservacion = fecha;
    }
    Fecha calculaFechaFinReserva(int cantDias)
    {
        return (fechaReservacion + cantDias);
    }
};
