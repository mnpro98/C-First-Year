#include <iostream>
#include <fstream>
#include "Libro.h"
#include "Disco.h"
#include "Software.h"
#include "Fecha.h"
#include "Reserva.h"

using namespace std;

Material *producto [20];
Reserva reservacion [50];

int main()
{
    //-----------------------------------------------------------------------------------------------
    int iId, iNum, iDuracion, dd, mm, aa, iIdCliente, iTamanoArrMat, iTamanoArrRes;
    string sTitulo, sAutor, sSisOp;
    char cMat;
    ifstream ifArchivoEntrada;
    ifArchivoEntrada.open("materiales.txt");
    for(iTamanoArrMat = 0; !ifArchivoEntrada.eof(); iTamanoArrMat++)
    {
        ifArchivoEntrada >> iId >> sTitulo >> cMat;
//        cout << iId << sTitulo << cMat;
        switch(cMat)
        {
        case 'L':
            ifArchivoEntrada >> iNum >> sAutor;
            producto[iTamanoArrMat] = new Libro(iId,sTitulo,iNum,sAutor);
//            cout << iNum << sAutor << endl;
            break;
        case 'D':
            ifArchivoEntrada >> iDuracion;
            producto[iTamanoArrMat] = new Disco(iId,sTitulo,iDuracion);
//            cout << iDuracion << endl;
            break;
        case 'S':
            ifArchivoEntrada >> sSisOp;
            producto[iTamanoArrMat] = new Software(iId,sTitulo,sSisOp);
//            cout << sSisOp << endl;
            break;
        }
    }
    ifArchivoEntrada.close();
//    cout << "Mierda" << endl;
    //---------------------------------------------------------------------------------------
    ifArchivoEntrada.open("reserva.txt");
    for(iTamanoArrRes = 0; !ifArchivoEntrada.eof(); iTamanoArrRes++)
    {
        Fecha F1;
        ifArchivoEntrada >> dd >> mm >> aa >> iId >> iIdCliente;
        F1.setFecha(dd,mm,aa);
        reservacion[iTamanoArrRes].setFecha(F1);
        reservacion[iTamanoArrRes].setMaterial(iId);
        reservacion[iTamanoArrRes].setCliente(iIdCliente);
//        cout << "Mierda" << endl;
    }
    ifArchivoEntrada.close();
    //-----------------------------------------------------------------------------------------
    ofstream ofArchivoSalida;
    char cOpcion = 'z';
    bool bFoundMat = false;
    bool bFoundRes = false;
    int iInput, iInput2;
    Fecha Finput;
    Fecha Finput2;
    Fecha F1;
    Reserva reserv;
    while (cOpcion != 'f')
    {
        bFoundMat = false;
        bFoundRes = false;
        cout << "a. Consultar la lista de Materiales" << endl;
        cout << "b. Consultar la lista de reservaciones" << endl;
        cout << "c. Consultar las reservaciones de un material dado" << endl;
        cout << "d. Consultar las reservaciones de una fecha dada" << endl;
        cout << "e. Hacer una reservacion" << endl;
        cout << "f. Terminar" << endl;

        cin >> cOpcion;

        switch(cOpcion)
        {
        case 'a':
            cout << "Lista de materiales:" << endl;
            for(int i = 0; i < iTamanoArrMat; i++)
            {
                producto[i]->muestra();
            }
            break;
        case 'b':
            cout << "Lista de reservaciones:" << endl;
            for(int i = 0; i < iTamanoArrRes; i++)
            {
                cout << reservacion[i].getFecha().getDd() << "/" << reservacion[i].getFecha().getMm() << "/" << reservacion[i].getFecha().getAa() << " " << reservacion[i].getMaterial() << " " << reservacion[i].getCliente() << endl;
            }
            break;
        case 'c':
            while(!bFoundMat || !bFoundRes)
            {
                cout << "Id material: ";
                cin >> iInput;
                for(int i = 0; i < iTamanoArrRes; i++)
                {
                    if(reservacion[i].getMaterial()==iInput)
                    {
                        bFoundRes = true;
                        for(int j = 0; j < iTamanoArrMat; j++)
                        {
                            if(producto[j]->getMat()==iInput)
                            {
                                bFoundMat = true;
                                cout << producto[j]->getTitulo() << endl;
                                cout << "Inicio: " << reservacion[i].getFecha().getDd() << "/" << reservacion[i].getFecha().getMm() << "/" << reservacion[i].getFecha().getAa() << endl;
                                cout << "Terminacion: " << reservacion[i].calculaFechaFinReserva(producto[j]->cantidadDeDiasDePrestamo()).getDd() << "/" << reservacion[i].calculaFechaFinReserva(producto[j]->cantidadDeDiasDePrestamo()).getMm() << "/" << reservacion[i].calculaFechaFinReserva(producto[j]->cantidadDeDiasDePrestamo()).getAa() << endl;
                            }
                        }
                    }
                }
            }
            break;
        case 'd':
            while(!bFoundMat || !bFoundRes)
            {
                cin >> Finput;
                for(int i = 0; i < iTamanoArrRes; i++)
                {
                    F1 = reservacion[i].getFecha();
                    for(int j = 0; j < iTamanoArrMat; j++)
                    {
                        if(producto[j]->getMat()==reservacion[i].getMaterial())
                        {
                            bFoundMat = true;
                            while(F1 <= reservacion[i].calculaFechaFinReserva(producto[j]->cantidadDeDiasDePrestamo()))
                            {
                                if(F1==Finput)
                                {
                                    bFoundRes = true;
                                    cout << producto[j]->getTitulo() << endl;
                                    cout << "Id cliente: " << reservacion[i].getCliente() << endl;
                                }
                                F1 = F1 + 1;
                            }
                        }
                    }
                }
            }
            break;
        case 'e':
            while(!bFoundMat||!bFoundRes)
            {
                bFoundMat = false;
                bFoundRes = true;
                cout << "Id cliente: ";
                cin >> iInput;
                cout << "Material: ";
                cin >> iInput2;
                cout << "Fecha: ";
                cin >> Finput;
                Finput2 = Finput;
                reserv.setCliente(iInput);
                reserv.setMaterial(iInput2);
                reserv.setFecha(Finput);
                for(int i = 0; i < iTamanoArrMat; i++)
                {
                    if(iInput2 == producto[i]->getMat())
                    {
                        bFoundMat = true;
                        for(int j = 0; j < iTamanoArrRes; j++)
                        {
                            if(reservacion[j].getMaterial() == iInput2)
                            {
                                for(int k = 0; k < iTamanoArrMat; k++)
                                {
                                    if(iInput2 == producto[k]->getMat())
                                    {
                                        Reserva reserv2 = reservacion[j];
                                        while(reserv2.getFecha() <= reservacion[j].calculaFechaFinReserva(producto[k]->cantidadDeDiasDePrestamo()))
                                        {
                                            while(Finput <= reserv.calculaFechaFinReserva(producto[k]->cantidadDeDiasDePrestamo()))
                                            {
                                                if(Finput == reserv2.getFecha())
                                                {
                                                    bFoundRes = false;
                                                }
                                                Finput = Finput + 1;
                                            }
                                            reserv2.setFecha(reserv2.getFecha() + 1);
                                            Finput = reserv.getFecha();
                                        }
                                    }
                                }
                            }
                        }
                        if(bFoundRes)
                        {
                            cout << "Reservacion a�adida con exito!" << endl;
                            reservacion[iTamanoArrRes] = reserv;
                            iTamanoArrRes++;
                        }
                    }
                }
                if(!bFoundRes)
                {
                    cout << "Espacio ya reservado..." << endl;
                }
                if(!bFoundMat)
                {
                    cout << "No se ha encontrado ningun material con el id especificado..." << endl;
                }
            }
            break;
        case 'f':
            ofArchivoSalida.open("reserva.txt");
            for(int i = 0; i < iTamanoArrRes; i++)
            {
                ofArchivoSalida << reservacion[i].getFecha().getDd() << " " << reservacion[i].getFecha().getMm() << " " << reservacion[i].getFecha().getAa() << " " << reservacion[i].getMaterial() << " " << reservacion[i].getCliente() << endl;
            }
            ofArchivoSalida.close();
            cout << "Hasta la proxima!" << endl;
            break;
        }
    }
    return 0;
}
