#include <iostream>
#include "Material.h"

using namespace std;

class Libro:public Material
{
private:
    int numPag;
    string sAutor;
public:
    Libro():Material()
    {
        numPag = 0;
        sAutor = "N/A";
    }
    Libro(int mat, string t, int pag, string autor):Material(mat,t)
    {
        numPag = pag;
        sAutor = autor;
    }

    int getNumPag()
    {
        return numPag;
    }
    string getAutor()
    {
        return sAutor;
    }

    void setNumPag(int pag)
    {
        numPag = pag;
    }
    void setAutor(string autor)
    {
        sAutor = autor;
    }

    virtual void muestra()
    {
        cout << "ID Material:\t" << idMaterial << endl;
        cout << "Titulo:\t" << titulo << endl;
        cout << "Numero de Paginas:\t" << numPag << endl;
        cout << "Autor:\t" << sAutor << endl;
    }
    virtual int cantidadDeDiasDePrestamo()
    {
        return 10;
    }
};
