#include <iostream>
#include "Esfera.h"
using namespace std;

int main()
{
    double radio;

    cout << "Dame un valor para el radio: ";
    cin >> radio;

    Esfera esfera1;
    Esfera esfera2(radio);

    cout << "Radio esfera1 = " << esfera1.getRadio() << endl;
    cout << "Area esfera1 = " << esfera1.calcArea() << endl;
    cout << "Volumen esfera1 = " << esfera1.calcVolum() << endl;

    cout << "Radio esfera2 = " << esfera2.getRadio() << endl;
    cout << "Area esfera2 = " << esfera2.calcArea() << endl;
    cout << "Volumen esfera2 = " << esfera2.calcVolum() << endl;

    Esfera esfera3 = esfera1.menor(esfera2);

    cout << "La esfera m�s peque�a tiene un radio de " << esfera3.getRadio() << endl;


    return 0;

}
