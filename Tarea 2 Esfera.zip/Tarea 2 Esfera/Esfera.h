#include <math.h>
#include <limits.h>

class Esfera
{
private:
    double radio;
public:
    Esfera();
    Esfera(double radio);

    double calcArea();
    double calcVolum();

    Esfera menor(Esfera esfera2);

//    Esfera menor();

    void setRadio(double radio);

    double getRadio();

};
Esfera::Esfera()
{
    radio = 1;
}

Esfera::Esfera(double radio)
{
    this->radio = radio;
}

void Esfera::setRadio(double radio)
{
    this->radio = radio;
}

double Esfera::getRadio()
{
    return radio;
}

double Esfera::calcArea()
{
    return M_PI*pow(radio, 2);
}
double Esfera::calcVolum()
{
    return 4/3*M_PI*pow(radio, 3);
}
Esfera Esfera::menor(Esfera esfera2)
{
    Esfera esfera3(this -> radio);
    if (esfera2.getRadio()>this ->radio)
    {
        return esfera3;
    } else if(this -> radio > esfera2.getRadio())
    {
        return esfera2;
    }
}
