#include <iostream>
#include "CuentaBancaria.h"

using namespace std;

class Chequera:public CuentaBancaria
{
private:
    double dComision;
public:
    Chequera(int iN, double iS, double dC):CuentaBancaria(iN,iS)
    {
        dComision = dC;
    }
    double retira(double dCont)
    {
        if(dSaldo >= (dCont * (dComision * 0.01 + 1)))
        {
            dSaldo -= (dCont * (dComision * 0.01 + 1));
        }
        return dSaldo;
    }
    void muestra()
    {
        cout << "Numero de cuenta: " << iNumCuenta << endl;
        cout << "Saldo: $" << dSaldo << endl;
        cout << "Comision: " << dComision << "%" << endl;
    }
};
