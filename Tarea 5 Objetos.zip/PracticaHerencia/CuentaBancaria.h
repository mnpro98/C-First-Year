#ifndef CuentaBancaria_h
#define CuentaBancaria_h
class CuentaBancaria
{
protected:
    int iNumCuenta;
    double dSaldo;
public:
    CuentaBancaria(int iN)
    {
        iNumCuenta = iN;
        dSaldo = 0;
    }
    CuentaBancaria(int iN, double iS)
    {
        iNumCuenta = iN;
        dSaldo = iS;
    }
    int getNumCuenta()
    {
        return iNumCuenta;
    }
    double getSaldo()
    {
        return dSaldo;
    }
    void setNumCuenta(int iN)
    {
        iNumCuenta = iN;
    }
    void setSaldo(double iS)
    {
        dSaldo = iS;
    }
    double deposita(double dCont)
    {
        dSaldo += dCont;
        return dSaldo;
    }
    double retira(double dCont)
    {
        if(dSaldo >= dCont)
        {
            dSaldo -= dCont;
            return dSaldo;
        }
    }
    virtual void muestra() = 0;
};
#endif /* CuentaBancaria_h */
