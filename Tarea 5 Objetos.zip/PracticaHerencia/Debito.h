#include <iostream>
#include "CuentaBancaria.h"

using namespace std;

class Debito:public CuentaBancaria
{
public:
    Debito(int iN, double iS) : CuentaBancaria(iN, iS)
    {

    }
    bool transferencias (double dCont, int iN)
    {
        if (dCont <= dSaldo)
        {
            dCont -= dSaldo;
            cout << "Su transaccion ha sido realizada con exito!" << endl;
            return true;
        }
        cout << "Su transaccion no ha sido posible, intentelo de nuevo." << endl;
        return false;
    }
    double bonoDeFondos()
    {
        dSaldo = dSaldo*1.01;
        return dSaldo;
    }
    void muestra()
    {
        cout << "Numero de cuenta: " << iNumCuenta << endl;
        cout << "Saldo: $" << dSaldo << endl;
    }
};
