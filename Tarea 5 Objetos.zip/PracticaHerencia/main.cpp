#include <iostream>
#include "Chequera.h"
#include "Credito.h"
#include "Debito.h"

using namespace std;

int main()
{
    Credito credito (1,100,3);
    Chequera chequera (2, 100, 50);
    Debito debito (3,100);

    cout << "Credito:" << endl;
    cout << "Antes:" << endl;
    credito.muestra();
    cout << credito.retira(10) << endl;
    cout << credito.deposita(20) << endl;
    cout << "Despues:" << endl;
    credito.muestra();

    cout << "Debito:" << endl;
    cout << "Antes:" << endl;
    debito.muestra();
    debito.transferencias(2,50);
    debito.bonoDeFondos();
    cout << "Despues:" << endl;
    debito.muestra();

    cout << "Chequera:" << endl;
    cout << "Antes:" << endl;
    chequera.muestra();
    chequera.retira(50);
    cout << "Despues:" << endl;
    chequera.muestra();

    return 0;
}
