#include <iostream>
#include "CuentaBancaria.h"

using namespace std;

class Credito:public CuentaBancaria
{
private:
    double dDeuda;
public:
    Credito(int iN, double iS):CuentaBancaria(iN, iS)
    {
        dDeuda = 0;
    }
    Credito(int iN, double iS, double dD):CuentaBancaria(iN,iS)
    {
        dDeuda = dD;
    }
    double deposita (double dCont)
    {
        if(dDeuda > dCont)
        {
            dDeuda -= dCont;
            return dSaldo;
        }
        else if (dDeuda == dCont)
        {
            dDeuda = 0;
            return dSaldo;
        }
        else if (dDeuda < dCont)
        {
            dCont -= dDeuda;
            dDeuda = 0;
            dSaldo += dCont;
            return dSaldo;
        }
    }
    double retira (double dCont)
    {
        if(dSaldo >= (dCont * 1.06))
        {
            dSaldo -= (dCont * 1.06);
            dDeuda += (dCont * 0.06);
            return dSaldo;
        }
    }
    void muestra()
    {
        cout << "Numero de cuenta: " << iNumCuenta << endl;
        cout << "Saldo: $" << dSaldo << endl;
        cout << "Deuda: $" << dDeuda << endl;
    }
};
