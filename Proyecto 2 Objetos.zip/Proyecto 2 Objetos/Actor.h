using namespace std;

class Actor
{
private:
    int iId;
    string sNombre;
public:
    Actor();
    Actor(int id, string nombre);

    int getId();
    string getNombre();

    void setId(int id);
    void setNombre(string nombre);

    void muestra();
};
Actor::Actor()
{
    iId = 0;
    sNombre = "SIN NOMBRE";
}
Actor::Actor(int id, string nombre)
{
    iId = id;
    sNombre = nombre;
}

int Actor::getId()
{
    return iId;
}
string Actor::getNombre()
{
    return sNombre;
}

void Actor::setId(int id)
{
    iId = id;
}
void Actor::setNombre(string nombre)
{
    sNombre = nombre;
}

void Actor::muestra()
{

}
