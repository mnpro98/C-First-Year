#include "Hora.h"

class Funcion
{
private:
    string cveFuncion;
    int iNumPeli, iSala;
    Hora hHora;
public:
    Funcion();
    Funcion(string funcion, int numPeli, int sala, Hora hora);

    string getFuncion();
    int getNumPeli();
    int getSala();
    Hora getHora();

    void setFuncion(string funcion);
    void setNumPeli(int numPeli);
    void setSala(int sala);
    void setHora(Hora hora);

    void muestra();
};
Funcion::Funcion()
{
    cveFuncion = "FUNCION";
    iNumPeli = 0;
    iSala = 0;
}
Funcion::Funcion(string funcion, int numPeli, int sala, Hora hora)
{
    cveFuncion = funcion;
    iNumPeli = numPeli;
    iSala = sala;
    hHora = hora;
}

string Funcion::getFuncion()
{
    return cveFuncion;
}
int Funcion::getNumPeli()
{
    return iNumPeli;
}
int Funcion::getSala()
{
    return iSala;
}
Hora Funcion::getHora()
{
    return hHora;
}

void Funcion::setFuncion(string funcion)
{
    cveFuncion = funcion;
}
void Funcion::setNumPeli(int numPeli)
{
    iNumPeli = numPeli;
}
void Funcion::setSala(int sala)
{
    iSala = sala;
}
void Funcion::setHora(Hora hora)
{
    hHora = hora;
}

void Funcion::muestra()
{

}
