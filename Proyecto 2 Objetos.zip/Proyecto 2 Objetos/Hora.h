class Hora
{
private:
    int iHh, iMm;
public:
    Hora();
    Hora(int hh, int mm);

    int getHh();
    int getMm();

    void setHh(int hh);
    void setMm(int mm);

    void muestra();
};
Hora::Hora()
{
    iHh = 0;
    iMm = 0;
}
Hora::Hora(int hh, int mm)
{
    iHh = hh;
    iMm = mm;
}

int Hora::getHh()
{
    return iHh;
}
int Hora::getMm()
{
    return iMm;
}

void Hora::setHh(int hh)
{
    iHh = hh;
}
void Hora::setMm(int mm)
{
    iMm = mm;
}

void Hora::muestra()
{

}
