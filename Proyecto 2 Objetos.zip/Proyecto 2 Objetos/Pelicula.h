class Pelicula
{
private:
    int iListaActores[10];
    int iNumPeli, iAno, iDuracion, iCantidadActores = 0;
    string sTitulo, sGenero;
public:
    Pelicula();
    Pelicula(int numPeli, int ano, int duracion, int listaActores[10], string titulo, string genero);

    int getNumPeli();
    int getAno();
    int getDuracion();
    string getTitulo();
    string getGenero();

    void setNumPeli(int peli);
    void setAno(int ano);
    void setDuracion(int duracion);
    void setTitulo(string titulo);
    void setGenero(string genero);

    int getListaActores(int i);
    int getCantidadActores();

    bool agregaActor(int id);
};
Pelicula::Pelicula()
{
    iNumPeli = 0;
    iAno = 0;
    iDuracion = 0;
    sTitulo = "TITULO";
    sGenero = "GENERO";
}
Pelicula::Pelicula(int numPeli, int ano, int duracion, int listaActores[10], string titulo, string genero)
{
    iNumPeli = numPeli;
    iAno = ano;
    iDuracion = duracion;
    sTitulo = titulo;
    sGenero = genero;
}

int Pelicula::getNumPeli()
{
    return iNumPeli;
}
int Pelicula::getAno()
{
    return iAno;
}
int Pelicula::getDuracion()
{
    return iDuracion;
}
string Pelicula::getTitulo()
{
    return sTitulo;
}
string Pelicula::getGenero()
{
    return sGenero;
}

void Pelicula::setNumPeli(int peli)
{
    iNumPeli = peli;
}
void Pelicula::setAno(int ano)
{
    iAno = ano;
}
void Pelicula::setDuracion(int duracion)
{
    iDuracion = duracion;
}
void Pelicula::setTitulo(string titulo)
{
    sTitulo = titulo;
}
void Pelicula::setGenero(string genero)
{
    sGenero = genero;
}

int Pelicula::getListaActores(int i)
{
    return iListaActores[i];
}
int Pelicula::getCantidadActores()
{
    return iCantidadActores;
}

bool Pelicula::agregaActor(int id)
{
    if(iCantidadActores == 10)
    {
        return false;
    } else
    {
        for (int i = 0; i < iCantidadActores; i++)
        {
            if (id == iListaActores[i])
            {
                return false;
            }
        }
        iListaActores[iCantidadActores] = id;
        iCantidadActores++;
        return true;
    }
}
