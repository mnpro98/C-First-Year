#include <iostream>
#include <fstream>
#include "Actor.h"
#include "Funcion.h"
#include "Pelicula.h"

using namespace std;

Actor actores [20];
Funcion funciones [20];
Pelicula pelicula [20];

int main()
{
    int iListaActores[10];
    int iId, id, iNumPelicula, iAno, iDuracion, iCantidad, iCantidadP = 0, iCantidadA = 0;
    string sActor, sGenero, sTitulo, clave;
    bool found;
    ifstream ifArchivoTexto;
    ifArchivoTexto.open("Actores.txt");
    for (int i = 0; !ifArchivoTexto.eof(); i++)
    {
        ifArchivoTexto >> iId;
        getline(ifArchivoTexto, sActor);
//        cout << iId << " " << sActor << endl;
        actores[i].setId(iId);
        actores[i].setNombre(sActor);
        iCantidadA++;
    }
    ifArchivoTexto.close();
    ifArchivoTexto.open("Peliculas.txt");
    for (int i = 0; !ifArchivoTexto.eof(); i++)
    {
        ifArchivoTexto >> iNumPelicula >> iAno >> iDuracion >> sGenero >> iCantidad;
        for (int j = 0; j < iCantidad; j++)
        {
            ifArchivoTexto >> iListaActores[j];
            pelicula[i].agregaActor(iListaActores[j]);
        }
        getline(ifArchivoTexto, sTitulo);
//        cout << iNumPelicula << " " << iAno << " " << iDuracion << " " << sGenero << " " << iCantidad << " ";
//        cout << sTitulo << endl;
        pelicula[i].setAno(iAno);
        pelicula[i].setDuracion(iDuracion);
        pelicula[i].setGenero(sGenero);
        pelicula[i].setNumPeli(iNumPelicula);
        pelicula[i].setTitulo(sTitulo);
        iCantidadP++;
    }
    ifArchivoTexto.close();
//-----------------------------------------------------------------------------------------------------------------------
    int iCantidadFunciones, iSala, iHh, iMm;
    string cveFuncion;
    Hora hora;
    while (iCantidadFunciones > 20 || iCantidadFunciones < 1)
    {
        cout << "Teclee el numero de funciones que habra: ";
        cin >> iCantidadFunciones;
    }
    for (int i = 0; i < iCantidadFunciones; i++)
    {
        do
        {
            found = false;
            cout << "Teclee la clave de la funcion " << i << ": ";
            cin >> cveFuncion;
            for (int j = 0; j < iCantidadFunciones; j++)
            {
                if (cveFuncion == funciones[j].getFuncion())
                {
                    cout << "Clave ya existente..." << endl;
                    found = true;
                }
            }
        }
        while (found);
        funciones[i].setFuncion(cveFuncion);
        found = false;
        while(!found)
        {
            cout << "Teclee el numero de la pelicula de la funcion " << i << ": ";
            cin >> iNumPelicula;
            for(int j = 0; (j < 20)&&(!found); j++)
            {
                if (iNumPelicula == pelicula[j].getNumPeli())
                {
                    funciones[i].setNumPeli(iNumPelicula);
                    found = true;
                }
            }
        }
        cout << "Teclee el numero de la sala de la funcion " << i << ": ";
        cin >> iSala;
        funciones[i].setSala(iSala);
        cout << "Teclee la hora de la funcion " << i << ": ";
        cin >> iHh;
        hora.setHh(iHh);
        cout << "Teclee el minuto de la funcion " << i << ": ";
        cin >> iMm;
        hora.setMm(iMm);
        funciones[i].setHora(hora);
    }
//--------------------------------------------------------------------------------------------------
    char cOpcion;
    while (cOpcion!='g')
    {
        cout << "Menu:" << endl;
        cout << "a) Consulta de todos los actores que estan en la lista." << endl;
        cout << "b) Consulta de todas las peliculas que estan en la lista." << endl;
        cout << "c) Consulta de todas las funciones disponibles." << endl;
        cout << "d) Consulta de funciones por hora." << endl;
        cout << "e) Consulta por clave de funcion." << endl;
        cout << "f) Consulta la lista de peliculas en las que participa un actor." << endl;
        cout << "g) Terminar." << endl;
        cin >> cOpcion;
        switch(cOpcion)
        {
        default:
            cout << "Escriba la letra de alguna de las opciones..." << endl;
            break;
        case 'a':
            for(int i = 0; i < iCantidadA; i++)
            {
                cout << actores[i].getId() << " " << actores[i].getNombre() << endl;
            }
            break;
        case 'b':
            for(int i = 0; i < iCantidadP; i++)
            {
                cout << pelicula[i].getNumPeli() << " " << pelicula[i].getAno() << " " << pelicula[i].getDuracion() << " " << pelicula[i].getGenero() << " " << pelicula[i].getCantidadActores() << " ";
                for (int j = 0; j < pelicula[i].getCantidadActores(); j++)
                {
                    cout << pelicula[i].getListaActores(j) << " ";
                }
                cout << pelicula[i].getTitulo() << endl;
            }
        case 'c':
            for(int i = 0; i < iCantidadFunciones; i++)
            {
                cout << "Funcion\tHora\tNumero de la pelicula\tSala" << endl;
                cout << funciones[i].getFuncion() << "\t" << funciones[i].getHora().getHh() << ":" << funciones[i].getHora().getMm() << "\t" << funciones[i].getNumPeli() << "\t\t\t" << funciones[i].getSala() << endl;
            }
            break;
        case 'd':
            int h, m;
            do
            {
                cout << "Hora: ";
                cin >> h;
            }
            while (h < 0 || h > 23);
            do
            {
                cout << "Minuto: ";
                cin >> m;
            }
            while (m < 0 || m > 59);
            for(int i = 0; i < iCantidadFunciones; i++)
            {
                if(funciones[i].getHora().getHh() == h && funciones[i].getHora().getMm() == m)
                {
                    for(int j = 0; j < iCantidadP; j++)
                    {
                        if(funciones[i].getNumPeli() == pelicula[j].getNumPeli())
                        {
                            cout << pelicula[j].getTitulo() << "\t\tSala " << funciones[i].getSala() << endl;
                        }
                    }
                }
            }
            break;
        case 'e':
            found = false;
            do
            {
                cout << "Busqueda por clave: ";
                cin >> clave;
                for(int i = 0; i < iCantidadFunciones; i++)
                {
                    if (funciones[i].getFuncion() == clave)
                    {
                        found = true;
                        for(int j = 0; j < iCantidadP; j++)
                        {
                            if(funciones[i].getNumPeli() == pelicula[j].getNumPeli())
                            {
                                cout << "Numero de Sala\t\tTitulo\t\t\tHora\tDuracion\tGenero\tActores" << endl;
                                cout << funciones[i].getSala() << "\t\t" << pelicula[j].getTitulo() << "\t" << funciones[i].getHora().getHh() << ":" << funciones[i].getHora().getMm() << "\t" << pelicula[j].getDuracion() << "\t" << pelicula[j].getGenero() << "\t";
                                for (int k = 0; k < pelicula[j].getCantidadActores(); k++)
                                {
                                    for(int l = 0; l < iCantidadA; l++)
                                    {
                                        if (pelicula[j].getListaActores(k) == actores[l].getId())
                                        {
                                            cout << actores[l].getNombre() << " ";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                cout << "\n";
            }
            while (!found);
            break;
        case 'f':
            found = false;
            do
            {
                cout << "Busqueda por actor: ";
                cin >> id;
                for(int i = 0; i < iCantidadA; i++)
                {
                    if (actores[i].getId() == id)
                    {
                        found = true;
                        for(int j = 0; j < iCantidadP; j++)
                        {
                            for (int k = 0; k < pelicula[j].getCantidadActores(); k++)
                            {
                                if (pelicula[j].getListaActores(k) == id)
                                {
                                    cout << pelicula[j].getTitulo() << " (" << pelicula[j].getAno() << ")" << endl;
                                }
                            }

                        }
                    }
                }
            }
            while (!found);
            break;
        case 'g':
            cout << "Hasta pronto!" << endl;
            break;
        }
    }
    return 0;
}
